# Flight-price-prediction
A model has been created and that model will predict the price of journey with flight
